"""Deprecated module for BaseLanguageModel class, kept for backwards compatibility."""

from __future__ import annotations

from langchain_core.language_models import BaseLanguageModel

__all__ = ["BaseLanguageModel"]
